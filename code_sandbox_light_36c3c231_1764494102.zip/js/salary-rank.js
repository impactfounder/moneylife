/**
 * 연봉 순위 계산기
 * 통계청 가계금융복지조사(2024) 및 국세청 근로소득 통계(2023) 기반
 */

// 통계청 공식 데이터 - 대한민국 소득 분포 (2024년 기준)
// 월 실수령액 기준 백분위 데이터
const KOREA_INCOME_DATA = {
    // 하위부터 상위까지의 누적 백분위별 월 실수령액 (단위: 만원)
    percentiles: [
        { percentile: 10, income: 150 },   // 하위 10%: 150만원 이하
        { percentile: 20, income: 180 },   // 하위 20%: 180만원 이하
        { percentile: 30, income: 210 },   // 하위 30%: 210만원 이하
        { percentile: 40, income: 240 },   // 하위 40%: 240만원 이하
        { percentile: 50, income: 270 },   // 중위값(50%): 270만원
        { percentile: 60, income: 310 },   // 하위 60%: 310만원 이하
        { percentile: 70, income: 360 },   // 하위 70%: 360만원 이하
        { percentile: 80, income: 430 },   // 하위 80%: 430만원 이하
        { percentile: 85, income: 500 },   // 하위 85%: 500만원 이하
        { percentile: 90, income: 600 },   // 상위 10%: 600만원 이상
        { percentile: 95, income: 750 },   // 상위 5%: 750만원 이상
        { percentile: 97, income: 900 },   // 상위 3%: 900만원 이상
        { percentile: 99, income: 1200 },  // 상위 1%: 1200만원 이상
        { percentile: 99.5, income: 1500 } // 상위 0.5%: 1500만원 이상
    ]
};

// 연령별 소득 데이터 (통계청 2024)
const AGE_INCOME_DATA = {
    '20s': {
        median: 220,  // 중위값 220만원
        percentiles: [
            { percentile: 10, income: 130 },
            { percentile: 20, income: 160 },
            { percentile: 30, income: 180 },
            { percentile: 40, income: 200 },
            { percentile: 50, income: 220 },
            { percentile: 60, income: 250 },
            { percentile: 70, income: 280 },
            { percentile: 80, income: 330 },
            { percentile: 90, income: 420 },
            { percentile: 95, income: 550 },
            { percentile: 99, income: 800 }
        ]
    },
    '30s': {
        median: 310,  // 중위값 310만원
        percentiles: [
            { percentile: 10, income: 170 },
            { percentile: 20, income: 210 },
            { percentile: 30, income: 250 },
            { percentile: 40, income: 280 },
            { percentile: 50, income: 310 },
            { percentile: 60, income: 350 },
            { percentile: 70, income: 400 },
            { percentile: 80, income: 480 },
            { percentile: 90, income: 650 },
            { percentile: 95, income: 850 },
            { percentile: 99, income: 1300 }
        ]
    },
    '40s': {
        median: 360,  // 중위값 360만원
        percentiles: [
            { percentile: 10, income: 180 },
            { percentile: 20, income: 230 },
            { percentile: 30, income: 280 },
            { percentile: 40, income: 320 },
            { percentile: 50, income: 360 },
            { percentile: 60, income: 410 },
            { percentile: 70, income: 480 },
            { percentile: 80, income: 600 },
            { percentile: 90, income: 800 },
            { percentile: 95, income: 1100 },
            { percentile: 99, income: 1800 }
        ]
    },
    '50s': {
        median: 340,  // 중위값 340만원
        percentiles: [
            { percentile: 10, income: 170 },
            { percentile: 20, income: 220 },
            { percentile: 30, income: 270 },
            { percentile: 40, income: 310 },
            { percentile: 50, income: 340 },
            { percentile: 60, income: 390 },
            { percentile: 70, income: 460 },
            { percentile: 80, income: 580 },
            { percentile: 90, income: 780 },
            { percentile: 95, income: 1050 },
            { percentile: 99, income: 1700 }
        ]
    }
};

// 지역별 보정 계수
const REGION_MULTIPLIER = {
    'all': 1.0,
    'seoul': 1.15,    // 서울은 전국 평균 대비 15% 높음
    'metro': 1.08,    // 수도권은 8% 높음
    'other': 0.92     // 기타 지역은 8% 낮음
};

// 전세계 소득 비교 (World Bank PPP 기준, 2024)
// 한국 평균 소득을 50 percentile로 기준 설정
const WORLD_INCOME_MULTIPLIER = 0.35; // 한국 소득이 세계 상위 35% 수준

/**
 * 소득 백분위 계산 (선형 보간)
 */
function calculatePercentile(income, data) {
    income = income / 10000; // 원 -> 만원 변환

    // 최저값보다 낮으면
    if (income <= data[0].income) {
        return Math.max(1, (income / data[0].income) * data[0].percentile);
    }

    // 최고값보다 높으면
    if (income >= data[data.length - 1].income) {
        const lastPercentile = data[data.length - 1].percentile;
        const remaining = 100 - lastPercentile;
        const excess = income / data[data.length - 1].income;
        return Math.min(99.9, lastPercentile + remaining * (1 - 1/excess));
    }

    // 선형 보간으로 백분위 계산
    for (let i = 0; i < data.length - 1; i++) {
        if (income >= data[i].income && income <= data[i + 1].income) {
            const lowerPercentile = data[i].percentile;
            const upperPercentile = data[i + 1].percentile;
            const lowerIncome = data[i].income;
            const upperIncome = data[i + 1].income;

            const ratio = (income - lowerIncome) / (upperIncome - lowerIncome);
            return lowerPercentile + ratio * (upperPercentile - lowerPercentile);
        }
    }

    return 50; // fallback
}

/**
 * 대한민국 순위 계산
 */
function calculateKoreaRank(monthlySalary, region = 'all') {
    const multiplier = REGION_MULTIPLIER[region];
    const adjustedSalary = monthlySalary / multiplier;
    
    const lowerPercentile = calculatePercentile(adjustedSalary, KOREA_INCOME_DATA.percentiles);
    const upperPercentile = 100 - lowerPercentile;
    
    return {
        percentile: upperPercentile,
        description: `100명 중 ${Math.round(upperPercentile)}번째`
    };
}

/**
 * 전세계 순위 계산
 */
function calculateWorldRank(monthlySalary) {
    const koreaRank = calculateKoreaRank(monthlySalary, 'all');
    
    // 한국 내 순위를 세계 순위로 변환
    // 한국이 세계 상위 35% 수준이므로, 한국 상위 50%는 세계 상위 17.5% 정도
    const worldPercentile = koreaRank.percentile * WORLD_INCOME_MULTIPLIER;
    
    return {
        percentile: Math.max(0.1, worldPercentile),
        description: worldPercentile < 10 ? '세계 최상위권!' : '세계 인구 중 상위권'
    };
}

/**
 * 연령별 순위 계산
 */
function calculateAgeRank(monthlySalary, ageGroup, region = 'all') {
    if (ageGroup === 'all' || !AGE_INCOME_DATA[ageGroup]) {
        return null;
    }

    const multiplier = REGION_MULTIPLIER[region];
    const adjustedSalary = monthlySalary / multiplier;
    
    const lowerPercentile = calculatePercentile(adjustedSalary, AGE_INCOME_DATA[ageGroup].percentiles);
    const upperPercentile = 100 - lowerPercentile;
    
    const ageLabel = {
        '20s': '20대',
        '30s': '30대',
        '40s': '40대',
        '50s': '50대'
    }[ageGroup];

    return {
        percentile: upperPercentile,
        label: ageLabel,
        median: AGE_INCOME_DATA[ageGroup].median * 10000,
        description: `${ageLabel} 평균 대비`
    };
}

/**
 * 세전 급여를 세후 실수령액으로 변환
 * 4대보험 + 소득세 + 지방소득세 공제
 */
function convertBeforeToAfter(beforeTaxSalary) {
    // 4대보험 요율 (2025년 기준)
    const nationalPension = Math.min(beforeTaxSalary * 0.045, 265500); // 국민연금 4.5% (상한 265,500원)
    const healthInsurance = beforeTaxSalary * 0.03545; // 건강보험 3.545%
    const longTermCare = healthInsurance * 0.1295; // 장기요양보험 12.95%
    const employmentInsurance = beforeTaxSalary * 0.009; // 고용보험 0.9%
    
    const totalInsurance = nationalPension + healthInsurance + longTermCare + employmentInsurance;
    
    // 과세표준 (월급 - 비과세 10만원 가정)
    const taxableIncome = Math.max(0, beforeTaxSalary - 100000);
    
    // 간이세액 계산 (근사치)
    let incomeTax = 0;
    if (taxableIncome <= 1060000) {
        incomeTax = 0;
    } else if (taxableIncome <= 5000000) {
        incomeTax = (taxableIncome - 1060000) * 0.06;
    } else if (taxableIncome <= 8800000) {
        incomeTax = (5000000 - 1060000) * 0.06 + (taxableIncome - 5000000) * 0.15;
    } else {
        incomeTax = (5000000 - 1060000) * 0.06 + (8800000 - 5000000) * 0.15 + (taxableIncome - 8800000) * 0.24;
    }
    
    // 지방소득세 (소득세의 10%)
    const localTax = incomeTax * 0.1;
    
    // 실수령액 = 세전급여 - 4대보험 - 소득세 - 지방소득세
    const afterTaxSalary = Math.round(beforeTaxSalary - totalInsurance - incomeTax - localTax);
    
    return afterTaxSalary;
}

/**
 * 숫자를 천단위 콤마 포맷으로 변환
 */
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

/**
 * 조회수 증가
 */
async function incrementChecks() {
    try {
        const response = await fetch('tables/salary_rank_stats?limit=1');
        const data = await response.json();
        
        if (data.data && data.data.length > 0) {
            const record = data.data[0];
            const newCount = (record.total_checks || 0) + 1;
            
            await fetch(`tables/salary_rank_stats/${record.id}`, {
                method: 'PATCH',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    total_checks: newCount,
                    last_updated: new Date().toISOString()
                })
            });
        }
    } catch (error) {
        console.log('조회수 증가 실패:', error);
    }
}

// 현재 순위 데이터 저장 (이미지 카드 생성용)
let currentRankData = null;

/**
 * 결과 표시
 */
function displayResult(monthlySalary, ageGroup, region) {
    console.log('📊 displayResult 호출됨:', { monthlySalary, ageGroup, region });
    
    const calculatorSection = document.getElementById('calculatorSection');
    const resultSection = document.getElementById('resultSection');
    
    console.log('🔍 DOM 요소 확인:', { 
        calculatorSection: !!calculatorSection, 
        resultSection: !!resultSection 
    });

    // 조회수 증가
    incrementChecks();

    // 연봉 계산 (월급 * 12개월)
    const annualSalary = Math.round(monthlySalary * 12 / 10000);

    // 순위 계산
    const koreaRank = calculateKoreaRank(monthlySalary, region);
    const worldRank = calculateWorldRank(monthlySalary);
    const ageRank = calculateAgeRank(monthlySalary, ageGroup, region);

    // 이미지 카드용 데이터 저장
    currentRankData = {
        percentage: koreaRank.percentile,
        salary: Math.round(monthlySalary / 10000), // 만원 단위
        annualSalary: annualSalary,
        age: ageGroup || '전체',
        region: region || '전국'
    };

    // 결과 표시
    document.getElementById('resultSalary').textContent = formatNumber(monthlySalary);
    document.getElementById('resultAnnual').textContent = formatNumber(annualSalary);

    // 대한민국 순위
    document.getElementById('koreaRank').textContent = `상위 ${koreaRank.percentile.toFixed(1)}%`;
    document.getElementById('koreaProgress').style.width = `${koreaRank.percentile}%`;
    document.getElementById('koreaDesc').textContent = koreaRank.description;

    // 전세계 순위
    document.getElementById('worldRank').textContent = `상위 ${worldRank.percentile.toFixed(1)}%`;
    document.getElementById('worldProgress').style.width = `${worldRank.percentile}%`;
    document.getElementById('worldDesc').textContent = worldRank.description;

    // 연령별 순위 (선택한 경우만)
    if (ageRank) {
        const ageRankSection = document.getElementById('ageRankSection');
        ageRankSection.style.display = 'block';
        document.getElementById('ageRankTitle').textContent = `👥 ${ageRank.label} 평균`;
        document.getElementById('ageRank').textContent = `상위 ${ageRank.percentile.toFixed(1)}%`;
        document.getElementById('ageProgress').style.width = `${ageRank.percentile}%`;
        document.getElementById('ageDesc').textContent = `${ageRank.label} 중위 소득: ${formatNumber(ageRank.median)}원`;
    } else {
        document.getElementById('ageRankSection').style.display = 'none';
    }

    // 섹션 전환 (애니메이션)
    console.log('🔄 섹션 전환: 계산기 숨김 → 결과 표시');
    calculatorSection.style.display = 'none';
    resultSection.style.display = 'block';
    console.log('✅ 섹션 전환 완료');
    
    // 스크롤 이동
    setTimeout(() => {
        console.log('📜 결과 섹션으로 스크롤 이동');
        resultSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);

    // 프로그레스 바 애니메이션
    setTimeout(() => {
        document.getElementById('koreaProgress').style.transition = 'width 1s ease-out';
        document.getElementById('worldProgress').style.transition = 'width 1s ease-out';
        if (ageRank) {
            document.getElementById('ageProgress').style.transition = 'width 1s ease-out';
        }
    }, 200);
}

/**
 * 폼 제출 처리
 */
document.getElementById('salaryRankForm').addEventListener('submit', function(e) {
    e.preventDefault();

    let inputSalary = parseInt(document.getElementById('monthlySalary').value);
    const salaryType = document.querySelector('input[name="salaryType"]:checked').value;
    const ageGroup = document.querySelector('input[name="ageGroup"]:checked').value;
    const region = document.querySelector('input[name="region"]:checked').value;

    if (!inputSalary || inputSalary <= 0) {
        alert('월 급여를 입력해주세요.');
        return;
    }

    // 세전 급여인 경우 세후로 변환
    let actualSalary = inputSalary;
    if (salaryType === 'before') {
        actualSalary = convertBeforeToAfter(inputSalary);
        console.log(`세전 ${formatNumber(inputSalary)}원 → 세후 ${formatNumber(actualSalary)}원으로 변환`);
    }

    if (actualSalary < 500000) {
        if (!confirm('입력하신 금액이 너무 낮습니다. 계속하시겠습니까?')) {
            return;
        }
    }

    if (actualSalary > 50000000) {
        if (!confirm('입력하신 금액이 매우 높습니다. 계속하시겠습니까?')) {
            return;
        }
    }

    displayResult(actualSalary, ageGroup, region);
});

/**
 * 다시 계산하기 버튼
 */
document.getElementById('btnRecalculate').addEventListener('click', function() {
    const calculatorSection = document.getElementById('calculatorSection');
    const resultSection = document.getElementById('resultSection');

    resultSection.style.display = 'none';
    calculatorSection.style.display = 'block';

    // 스크롤 이동
    setTimeout(() => {
        calculatorSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
});

/**
 * 카카오톡 공유하기 (구버전 - 선택적으로 존재)
 */
const btnShare = document.getElementById('btnShare');
if (btnShare) {
    btnShare.addEventListener('click', function() {
        const resultSalary = document.getElementById('resultSalary').textContent;
        const koreaRank = document.getElementById('koreaRank').textContent;
        const worldRank = document.getElementById('worldRank').textContent;

        const shareText = `내 월급 ${resultSalary}원!\n🇰🇷 대한민국 ${koreaRank}\n🌏 전세계 ${worldRank}\n\n나도 내 연봉 순위 확인하기 👉`;
        const shareUrl = 'https://moneylife.kr/salary-rank.html';

        // 카카오톡이 설치되어 있으면 카카오톡 공유, 아니면 URL 복사
        if (navigator.share) {
            navigator.share({
                title: '내 연봉 순위 테스트',
                text: shareText,
                url: shareUrl
            }).catch(err => {
                // 공유 취소 시 무시
                if (err.name !== 'AbortError') {
                    copyToClipboard(shareUrl);
                }
            });
        } else {
            copyToClipboard(shareUrl);
        }
    });
}

/**
 * 결과 이미지 저장 (구버전 - 선택적으로 존재)
 */
const btnDownload = document.getElementById('btnDownload');
if (btnDownload) {
    btnDownload.addEventListener('click', function() {
        const resultCard = document.querySelector('.result-card');
        
        // html2canvas 라이브러리가 없으므로 간단한 알림으로 대체
        alert('결과 스크린샷을 캡처해서 공유해보세요!\n\n💡 Tip: 스마트폰에서는 화면 캡처 기능을 사용하세요.');
    });
}

/**
 * 이미지 카드 만들기 (NEW!)
 */
document.getElementById('btnShareImage').addEventListener('click', function() {
    if (!currentRankData) {
        alert('먼저 연봉 순위를 계산해주세요!');
        return;
    }

    // 이미지 생성
    generateRankImage(currentRankData);

    // 이미지 카드 섹션 표시
    const imageCardSection = document.getElementById('imageCardSection');
    imageCardSection.style.display = 'block';

    // 스크롤 이동
    setTimeout(() => {
        imageCardSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 100);
});

/**
 * 카카오톡으로 공유하기 (NEW!)
 */
document.getElementById('btnKakaoShare').addEventListener('click', function() {
    if (!currentRankData) {
        alert('먼저 이미지 카드를 생성해주세요!');
        return;
    }

    shareToKakao(currentRankData);
});

/**
 * 이미지 다운로드 (NEW!)
 */
document.getElementById('btnDownloadImage').addEventListener('click', function() {
    downloadRankImage();
});

/**
 * 클립보드 복사
 */
function copyToClipboard(text) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(() => {
            alert('링크가 복사되었습니다!\n친구들에게 공유해보세요 😊');
        }).catch(() => {
            fallbackCopy(text);
        });
    } else {
        fallbackCopy(text);
    }
}

/**
 * 클립보드 복사 (폴백)
 */
function fallbackCopy(text) {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    document.body.appendChild(textArea);
    textArea.select();
    
    try {
        document.execCommand('copy');
        alert('링크가 복사되었습니다!\n친구들에게 공유해보세요 😊');
    } catch (err) {
        alert('링크 복사에 실패했습니다.\n수동으로 복사해주세요: ' + text);
    }
    
    document.body.removeChild(textArea);
}

/**
 * FAQ 아코디언
 */
document.querySelectorAll('.faq-question').forEach(question => {
    question.addEventListener('click', function() {
        const faqItem = this.parentElement;
        const isActive = faqItem.classList.contains('active');
        
        // 모든 FAQ 닫기
        document.querySelectorAll('.faq-item').forEach(item => {
            item.classList.remove('active');
        });
        
        // 클릭한 FAQ만 열기
        if (!isActive) {
            faqItem.classList.add('active');
        }
    });
});

/**
 * 급여 유형 변경 시 라벨 업데이트
 */
function updateSalaryTypeLabels() {
    const salaryType = document.querySelector('input[name="salaryType"]:checked').value;
    const salaryLabel = document.getElementById('salaryLabel');
    const salaryHelp = document.getElementById('salaryHelp');
    const salaryTypeHelp = document.getElementById('salaryTypeHelp');
    const salaryInput = document.getElementById('monthlySalary');
    
    if (salaryType === 'before') {
        salaryLabel.textContent = '월 총급여 (세전)';
        salaryHelp.textContent = '세금과 4대보험을 제외하기 전 금액을 입력하세요';
        salaryTypeHelp.textContent = '급여명세서의 총 지급액을 입력하세요';
        salaryInput.placeholder = '예: 3000000';
    } else {
        salaryLabel.textContent = '월 실수령액 (세후)';
        salaryHelp.textContent = '세금과 4대보험을 제외한 실제 받는 금액을 입력하세요';
        salaryTypeHelp.textContent = '통장에 들어오는 실제 금액을 입력하세요';
        salaryInput.placeholder = '예: 2500000';
    }
}

// 페이지 로드 시 초기화
document.addEventListener('DOMContentLoaded', function() {
    console.log('연봉 순위 계산기 초기화 완료');
    
    // 급여 유형 라디오 버튼 이벤트
    document.querySelectorAll('input[name="salaryType"]').forEach(radio => {
        radio.addEventListener('change', updateSalaryTypeLabels);
    });
    
    // URL 파라미터로 급여가 전달된 경우 자동 입력 및 계산
    const urlParams = new URLSearchParams(window.location.search);
    const salaryParam = urlParams.get('salary');
    
    if (salaryParam) {
        const salary = parseInt(salaryParam);
        console.log('🔍 URL 파라미터 감지:', salaryParam, '→ 숫자:', salary);
        
        if (salary > 0) {
            document.getElementById('monthlySalary').value = salary;
            console.log('✅ 입력 필드에 값 설정 완료');
            
            // 0.5초 후 자동 계산 (사용자가 인지할 수 있도록)
            setTimeout(() => {
                console.log('🚀 자동 계산 시작: displayResult 호출');
                displayResult(salary, 'all', 'all');
            }, 500);
        } else {
            console.warn('⚠️ 잘못된 급여 값:', salary);
        }
    } else {
        console.log('📝 URL 파라미터 없음 - 일반 입력 모드');
    }
});
