/**
 * 연봉 순위 이미지 카드 생성기
 * Canvas API를 사용한 3티어 디자인
 */

// Kakao SDK 초기화
// ✅ JavaScript 키 설정 완료 (2025-01-23)
// 앱: moneylife (ID: 1342089)
if (typeof Kakao !== 'undefined' && !Kakao.isInitialized()) {
    Kakao.init('2e34fd72aa8a49ccbd7d9b3a3054f6ee');
    console.log('✅ Kakao SDK 초기화 완료');
}

/**
 * 티어 정보 반환
 */
function getTierInfo(percentage) {
    if (percentage <= 10) {
        return {
            name: 'VIP',
            tier: '🥇 VIP 티어',
            colorStart: '#FFD700',
            colorEnd: '#FFA500',
            textColor: '#FFFFFF',
            accentColor: '#FFF8DC',
            message: '대한민국 상위권입니다! 🏆',
            badge: 'TOP 10%'
        };
    } else if (percentage <= 30) {
        return {
            name: 'Premium',
            tier: '🥈 프리미엄 티어',
            colorStart: '#E8E8E8',
            colorEnd: '#A0A0A0',
            textColor: '#2C3E50',
            accentColor: '#34495E',
            message: '평균 이상이에요! ⭐',
            badge: 'TOP 30%'
        };
    } else {
        return {
            name: 'Standard',
            tier: '📊 스탠다드',
            colorStart: '#667eea',
            colorEnd: '#764ba2',
            textColor: '#FFFFFF',
            accentColor: '#E8EAF6',
            message: '성장 가능성이 있어요! 💪',
            badge: ''
        };
    }
}

/**
 * Canvas에 텍스트를 중앙 정렬하여 그리기
 */
function drawCenteredText(ctx, text, y, fontSize, fontWeight = 'normal', color = '#FFFFFF') {
    ctx.font = `${fontWeight} ${fontSize}px 'Pretendard', -apple-system, BlinkMacSystemFont, sans-serif`;
    ctx.fillStyle = color;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, 540, y);
}

/**
 * 둥근 사각형 그리기
 */
function roundRect(ctx, x, y, width, height, radius) {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
}

/**
 * 메인 이미지 생성 함수
 */
function generateRankImage(data) {
    const { percentage, salary, annualSalary, age, region } = data;
    const tier = getTierInfo(percentage);
    
    // Canvas 생성 (1080x1350px - 인스타그램 세로 비율)
    const canvas = document.getElementById('rankImageCanvas');
    const ctx = canvas.getContext('2d');
    
    // 고해상도 설정
    const scale = 2;
    canvas.width = 1080 * scale;
    canvas.height = 1350 * scale;
    ctx.scale(scale, scale);
    
    // 배경 그라디언트
    const gradient = ctx.createLinearGradient(0, 0, 0, 1350);
    gradient.addColorStop(0, tier.colorStart);
    gradient.addColorStop(1, tier.colorEnd);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 1080, 1350);
    
    // 상단: 로고 및 브랜딩
    ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
    roundRect(ctx, 40, 40, 1000, 80, 20);
    ctx.fill();
    
    drawCenteredText(ctx, '💰 moneylife.kr', 100, 32, 'bold', tier.textColor);
    if (tier.badge) {
        drawCenteredText(ctx, tier.badge, 140, 24, 'bold', tier.accentColor);
    }
    
    // 중앙 상단: 타이틀
    drawCenteredText(ctx, '대한민국 소득 순위', 250, 36, '600', tier.textColor);
    
    // 메인 박스: 순위 표시
    ctx.fillStyle = 'rgba(255, 255, 255, 0.95)';
    ctx.shadowColor = 'rgba(0, 0, 0, 0.2)';
    ctx.shadowBlur = 30;
    ctx.shadowOffsetY = 10;
    roundRect(ctx, 140, 320, 800, 380, 30);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.shadowOffsetY = 0;
    
    // 순위 숫자 (메인)
    const percentText = percentage.toFixed(1);
    ctx.font = 'bold 140px sans-serif';
    ctx.fillStyle = tier.colorStart;
    ctx.textAlign = 'center';
    ctx.fillText('상위', 540, 450);
    
    ctx.font = 'bold 200px sans-serif';
    ctx.fillStyle = tier.colorEnd;
    ctx.fillText(`${percentText}%`, 540, 600);
    
    // 월급 정보
    ctx.font = '600 32px sans-serif';
    ctx.fillStyle = '#34495E';
    ctx.fillText(`월 ${salary}만원`, 540, 680);
    
    // 하단: 부가 정보
    const infoY = 780;
    ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
    roundRect(ctx, 80, infoY, 920, 200, 20);
    ctx.fill();
    
    drawCenteredText(ctx, tier.message, infoY + 50, 32, '600', tier.textColor);
    drawCenteredText(ctx, `${age || '전체'} · ${region || '전국'}`, infoY + 100, 24, 'normal', tier.accentColor);
    drawCenteredText(ctx, `연봉 약 ${annualSalary}만원`, infoY + 140, 26, 'normal', tier.accentColor);
    
    // 하단: CTA 및 해시태그
    const bottomY = 1050;
    drawCenteredText(ctx, '#연봉순위 #내연봉 #소득분포', bottomY, 28, '500', tier.textColor);
    drawCenteredText(ctx, 'moneylife.kr에서 확인하세요 →', bottomY + 60, 26, 'normal', tier.accentColor);
    
    // 워터마크 (우측 하단)
    ctx.font = '18px sans-serif';
    ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
    ctx.textAlign = 'right';
    const now = new Date();
    const dateStr = `${now.getFullYear()}.${String(now.getMonth() + 1).padStart(2, '0')}.${String(now.getDate()).padStart(2, '0')}`;
    ctx.fillText(`© moneylife.kr ${dateStr}`, 1040, 1310);
    
    return canvas;
}

/**
 * 이미지 다운로드
 */
function downloadRankImage() {
    const canvas = document.getElementById('rankImageCanvas');
    canvas.toBlob((blob) => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `내연봉순위_${Date.now()}.png`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }, 'image/png');
}

/**
 * 카카오톡 공유
 */
function shareToKakao(data) {
    if (typeof Kakao === 'undefined') {
        alert('카카오톡 SDK가 로드되지 않았습니다.');
        return;
    }
    
    const { percentage, salary } = data;
    const tier = getTierInfo(percentage);
    
    // 이미지를 서버에 업로드해야 하지만, 정적 사이트이므로
    // 일단 텍스트 공유로 구현 (나중에 이미지 업로드 서비스 연동)
    Kakao.Share.sendDefault({
        objectType: 'feed',
        content: {
            title: `나는 대한민국 상위 ${percentage.toFixed(1)}%!`,
            description: `월급 ${salary}만원, ${tier.tier}\n너는 상위 몇 %? 확인해봐!`,
            imageUrl: 'https://moneylife.kr/images/og-image.jpg',
            link: {
                mobileWebUrl: 'https://moneylife.kr/salary-rank.html',
                webUrl: 'https://moneylife.kr/salary-rank.html'
            }
        },
        buttons: [
            {
                title: '내 순위 확인하기',
                link: {
                    mobileWebUrl: 'https://moneylife.kr/salary-rank.html',
                    webUrl: 'https://moneylife.kr/salary-rank.html'
                }
            }
        ]
    });
}

/**
 * URL 복사 (대체 공유 방법)
 */
function copyUrlToClipboard() {
    const url = window.location.href;
    if (navigator.clipboard) {
        navigator.clipboard.writeText(url).then(() => {
            alert('✅ URL이 복사되었습니다!\n카카오톡이나 SNS에 붙여넣기 하세요.');
        }).catch(() => {
            fallbackCopyToClipboard(url);
        });
    } else {
        fallbackCopyToClipboard(url);
    }
}

function fallbackCopyToClipboard(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    try {
        document.execCommand('copy');
        alert('✅ URL이 복사되었습니다!');
    } catch (err) {
        alert('❌ 복사에 실패했습니다. URL을 직접 복사해주세요:\n' + text);
    }
    document.body.removeChild(textarea);
}

// 전역 함수로 export
window.generateRankImage = generateRankImage;
window.downloadRankImage = downloadRankImage;
window.shareToKakao = shareToKakao;
window.copyUrlToClipboard = copyUrlToClipboard;
